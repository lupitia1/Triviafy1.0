﻿# Triviafy

Software destinado al entretenimiento del usuario mediante la adivinación de entre cuatro canciones a partir del audio proporcionado por Spotify.

## **Componentes**:


### Servicio C#: 
Instancia del servicio web conectado a la API de Spotify en EC2 automáticamente nos genera almacenamiento en Elastic Beansk

### App JavaScript: 
Aplicativo visual que consume el servicio y aporta la visualización de los datos.

### Spotify API: 
API que nos brinda la data de canciones e información de artistas y álbumes.


## **Instalación y uso:**
Para el uso de la app se debe ejecutar el servicio middleware que trata la data de la API, conectándose con la aplicación. 

Abrir el archivo index.html para comenzar el juego.

(Es necesario para el juego un token aportado por el SDK player de Spotify encontrado aquí: https://developer.spotify.com/documentation/web-playback-sdk/quick-start/#

=> Se sustituye el nuevo token en la variable token de /js/bundle.js)

## **Estructura de carpetas:**

Triviafy
> 	index.html (estructura del cliente).
	> /css (estilos).
	> /js (lógica).
	/js/blunde.js => Archivo generado por `browserify`  a partir de nuestro archivo `main.js` para permitir funcionalidades dentro del browser sin necesidad de un servidor, como lo es `require()`
	>/node_modules (módulos npm utilizados en el proyecto).

Librerias mas importantes en el proyecto de npm:

 - browserify
 - bulma.css
 - animate.css
 - soap
 - node-wsdl
 - spotify-web-sdk


## **Arquitectura:**
<a href="https://ibb.co/S6jxry1"><img src="https://i.ibb.co/YNCWZQK/aRQ.png" alt="aRQ" border="0"></a><br />
